﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class MultiUnit :Housing
    {
        private int NoOfUnits;

        public int Unit
        {
            get
            {
                return NoOfUnits;
            }
            set
            {
                NoOfUnits = value;
            }
        }
        public void PrintInfo()
        {
            base.PrintInfo();
            Console.WriteLine("No of Units of house are {0} ",NoOfUnits);
        }
    }
}
