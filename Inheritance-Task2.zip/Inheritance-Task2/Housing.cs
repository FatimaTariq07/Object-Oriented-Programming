﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Housing
    {
        private string Address;
        private int YearBuilt;

        public string Ad_Home
        {
            get
            {
                return Address;
            }
            set
            {
                Address = value;
            }
        }
        public int year
        {
            get
            {
                return YearBuilt;
            }
            set
            {
                YearBuilt = value;
            }
        }
        public void PrintInfo()
        {
            Console.WriteLine("Address of house is {0} ",Address);
            Console.WriteLine("The year in which built {0} ",year);
        }
    }
}
