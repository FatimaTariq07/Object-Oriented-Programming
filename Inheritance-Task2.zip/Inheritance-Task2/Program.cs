﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            MultiUnit obj1 = new MultiUnit();
            obj1.Ad_Home = "Gulistan colony";
            obj1.year = 1998;
            obj1.Unit = 45;
            obj1.PrintInfo();

            Console.WriteLine("--------------------------------------------------------");
            SingleFamily obj2 = new SingleFamily();
            obj2.Ad_Home = "Eden valley";
            obj2.year = 1998;
            obj2.SqaureSize = 25.7;
            obj2.Garage = "yes";
            obj2.PrintInfo();

        }
    }
}
