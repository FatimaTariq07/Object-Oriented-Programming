﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class SingleFamily : Housing
    {
        private double Size;
        private string garage;

        public double SqaureSize
        {
            get
            {
                return Size;
            }
            set
            {
                Size = value;
            }
        }
        public string Garage
        {
            get
            {
                return garage;
            }
            set
            {
                garage = value;
            }
        }
        public void PrintInfo()
        {
            base.PrintInfo();
            Console.WriteLine("Size in sq feet of house are {0} ", Size);
            Console.WriteLine("Garage availability in house is {0} ",garage);
        }
    }
}
