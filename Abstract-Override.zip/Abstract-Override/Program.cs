﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qno1
{
    class Program
    {
        static void Main(string[] args)
        {
            Person obj = new Student("Fatima", "21-1222", 2002, "Computer Science", "21-NTU-CS-1222");
            obj.Display();
        }
    }
}
