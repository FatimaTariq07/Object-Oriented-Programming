﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qno1
{
    abstract class Person
    {
        protected string name;
        protected string SocialNum;
        protected int YearBirth;

        public Person(string name, string SocialNum, int YearBirth)
        {
            this.name = name;
            this.SocialNum = SocialNum;
            this.YearBirth = YearBirth;
        }
        public abstract void Display();
        
    }
}
