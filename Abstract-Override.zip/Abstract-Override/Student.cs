﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Qno1
{
    class Student:Person
    {
        private string major;
        private string RegNo;

        public Student(string name, string SocialNum, int YearBirth, string major, string RegNo)
            : base(name, SocialNum, YearBirth)
        {
            this.major = major;
            this.RegNo = RegNo;
        }
         public override void Display()
        {
            Console.WriteLine("Name of person is {0} \n Social Num is {1} \n Year of birth is {2} \n Major of student is {3} \n Regno of student is {4} ", name, SocialNum, YearBirth, major, RegNo);
        }
    }
}
