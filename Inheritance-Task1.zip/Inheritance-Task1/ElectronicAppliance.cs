﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class ElectronicAppliance : Assets
    {
         private string ApplianceName;
        private int A_Price;

        public ElectronicAppliance(string AssetID, string AssetLocation, string ApplianceName, int A_Price)
            : base(AssetID, AssetLocation)
        {
            this.ApplianceName = ApplianceName;
            this.A_Price = A_Price;
        }
        public void Display()
        {
            base.Display();
            Console.WriteLine("Electronic applaince name is {0} ",ApplianceName);
            Console.WriteLine("Appliance price is {0} ",A_Price);
        }
    }
}
