﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Assets
    {
        private string AssetID;
        private string AssetLocation;

        public Assets(string AssetID,string AssetLocation)
        {
            this.AssetID = AssetID;
            this.AssetLocation = AssetLocation;
        }
        public void Display()
        {
            Console.WriteLine("ID of asset is {0} ",AssetID);
            Console.WriteLine("Location of asset is {0} ",AssetLocation);
        }
        
    }
}
