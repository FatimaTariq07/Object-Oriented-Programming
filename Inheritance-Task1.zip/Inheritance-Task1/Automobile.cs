﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Automobile : Assets
    {
        private string AutoName;
        private string AutoModel;

        public Automobile(string AssetID, string AssetLocation,string AutoName,string AutoModel):base(AssetID,AssetLocation)
        {
            this.AutoName = AutoName;
            this.AutoModel = AutoModel;
        }
        public void Display()
        {
            base.Display();
            Console.WriteLine("Automobile name is {0} ",AutoName);
            Console.WriteLine("Automobile Model is {0} ",AutoModel);
        }
    }
}
