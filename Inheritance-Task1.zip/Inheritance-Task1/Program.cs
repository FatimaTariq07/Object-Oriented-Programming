﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            Automobile obj1 = new Automobile("12FA", "Lahore", "Car", "Civic 2017");
            obj1.Display();

            Console.WriteLine("----------------------------------------------");

            ElectronicAppliance obj2 = new ElectronicAppliance("13RE", "Faisalabad", "AC", 45000);
            obj2.Display();
        }
    }
}
