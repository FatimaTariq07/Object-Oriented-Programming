﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            bool result;
            Multiple obj1 = new Multiple();
            obj1.Input();
            result = obj1.CheckMultiple();
            obj1.Display(result);

        }
    }
}
