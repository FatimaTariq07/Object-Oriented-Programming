﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Multiple
    {
        private int num1;
        private int num2;

        public void Input()
        {
            Console.Write("Enter 1st number : ");
            num1 = int.Parse(Console.ReadLine());
            Console.Write("Enter 2nd number : ");
            num2 = int.Parse(Console.ReadLine());

        }
        public bool CheckMultiple()
        {
            bool result = true;
            if (num2 / num1 == 0)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }
        public void Display(bool res)
        {
            if(res==true)
            {
                Console.WriteLine("First is multiple of second");

            }
            else
            {
                Console.WriteLine("Not multiple!!!");
            }
        }
    }
}
